package com.capgemini.training.lab6exercises;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Lab6_ex4 {
 
	private static Scanner sc=new Scanner(System.in);
	public static void main(String args[]) {
		HashMap<String,Integer> studentMap=new HashMap<>();
		int no=0;
		System.out.println("Enter no of students:");
		no=Integer.parseInt(sc.nextLine());
		for(int i=0;i<no;i++) {
			System.out.println("Enter student regitration number: ");
			String registrationNumber=sc.nextLine();
			System.out.println("Enter student mark:");
			int marks=Integer.parseInt(sc.nextLine());
			studentMap.put(registrationNumber, marks);
		}
		
		HashMap<String,String> outputMap=getStudents(studentMap);
	    System.out.println(outputMap);
		
	}
	
	private static HashMap<String,String>getStudents(HashMap<String,Integer>studentMap){
		
		HashMap<String,String>hm=new HashMap<>();
		String medal=null;
		for(Map.Entry<String, Integer> entry:studentMap.entrySet()) {
			if(entry.getValue()>=90) {
				medal="Gold";
			}
			else if(entry.getValue()>=80) {
				medal="Silver";
			}
			else if(entry.getValue()>=70) {
				medal="Bronze";
			}
			else
				System.out.println("Invalid marks..");
	      
			hm.put(entry.getKey(), medal);
		
		}
		
		
		return hm;
		
	}
	
}

