package com.capgemini.training.lab6exercises;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Lab6_ex3 {

	private static Scanner sc=new Scanner(System.in);
	
	public static void main(String args[]) {
		
		int size;
		System.out.println("Enter size of array:");
		size=Integer.parseInt(sc.nextLine());
		int arr[]=new int[size];
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
		
		HashMap<Integer,Integer>squareMap=getSquares(arr);
		System.out.println(squareMap);
	}
	
	private static HashMap<Integer,Integer> getSquares(int[] arr){
      HashMap<Integer,Integer> hm=new HashMap<>();
      for(int i:arr) {
    	  int square=i*i;
    	  hm.put(i,square);
      }
      
	return hm;
      
	}
}
