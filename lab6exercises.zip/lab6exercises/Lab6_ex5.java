package com.capgemini.training.lab6exercises;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Lab6_ex5 {

	private static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		
		int no;
		System.out.println("Enter the size of the array:");
		no=Integer.parseInt(sc.nextLine());
		int arr[]=new int[no];
		System.out.println("Enter the elements in array:");
		for(int i=0;i<no;i++) {
			arr[i]=sc.nextInt();
		}
		
		int secondSmallest=getSecondSmallest(arr);
       System.out.println("second smallest element :"+secondSmallest);
	}
	
	private static int getSecondSmallest(int[] arr) {
		int secondsmallestElement;
        List<Integer>list1=new ArrayList();
	     for(int i=0;i<arr.length;i++) {
	    	 list1.add(arr[i]);
	     }
		Collections.sort(list1);
		secondsmallestElement=list1.get(1);
		
		return secondsmallestElement;
	}

}
