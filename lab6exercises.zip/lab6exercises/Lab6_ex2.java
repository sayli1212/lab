package com.capgemini.training.lab6exercises;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Lab6_ex2 {

	private static Scanner sc=new Scanner(System.in);
  public static void main(String args[]) {
	
	  
	int no;
	System.out.println("Enter the String: ");
	String str=sc.nextLine();
	char arr[]=str.toCharArray();
	HashMap<Character,Integer> outputMap=countChars(arr);
	System.out.println(outputMap);
	
}
  
  
  private static HashMap<Character,Integer>countChars(char[] arr){
	  HashMap<Character,Integer>hm=new HashMap<>();
	  for (char c : arr)
      {
          if(hm.containsKey(c))
          {
                 hm.put(c, hm.get(c)+1);
          }
          else
          {
               hm.put(c, 1);
          }
      }
    
     return hm;
  }

}
