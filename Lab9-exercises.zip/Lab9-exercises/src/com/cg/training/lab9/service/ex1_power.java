package com.cg.training.lab9.service;

public interface ex1_power {

	public abstract int powerOf(int num1,int num2);
}
