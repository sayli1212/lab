package com.cg.training.lab9.service;

public interface Ex3CredentialCheck {
 
	public abstract boolean Check(String userName,String password);
	
}
