package com.cg.training.lab9.client;

@FunctionalInterface
interface StringSpace{
	String space(String str1);
}



public class Lab9Ex2 {
	
	public static void main(String args[]) {
		StringSpace spaceinserter=(str)->{
			String[] s=str.split("");
			String spacedString="";
			for(String string : s) {
				spacedString +=string + " ";
			}
			return spacedString;
		};
		
		System.out.println(spaceinserter.space("CG"));
		
	}

}
