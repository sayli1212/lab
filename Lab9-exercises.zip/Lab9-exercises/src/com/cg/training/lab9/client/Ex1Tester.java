package com.cg.training.lab9.client;

import com.cg.training.lab9.service.ex1_power;

public class Ex1Tester {

	public static void main(String args[]) {
		
		ex1_power powerfinder=(num1,num2)->{
			int power=num1;
			for(int i=1;i<num2;i++) {
				power=power*num1;
			}
			return power;
	};
		System.out.println(powerfinder.powerOf(2, 4));
		
		
		
	}
	
}
