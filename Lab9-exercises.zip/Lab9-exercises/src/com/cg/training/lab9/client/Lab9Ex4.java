package com.cg.training.lab9.client;

@FunctionalInterface
	interface student{
		demo getName(String name);
	}
	

class demo{
	
	private String name;

	public demo() {
		super();
	}

	public demo(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return " [name=" + name + "]";
	}
	
	
}


public abstract class Lab9Ex4 implements student{
	public static void main(String args[]) {
	student s=demo:: new;
	System.out.println(s.getName("Sayli"));
}
}