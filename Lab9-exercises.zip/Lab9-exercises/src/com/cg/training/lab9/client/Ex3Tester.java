package com.cg.training.lab9.client;

import com.cg.training.lab9.service.Ex3CredentialCheck;

public class Ex3Tester {
 
	
	public static void main(String args[]) {
     
		Ex3CredentialCheck checker=(username,password)->{
			if(username.equals("admin")&&password.equals("admin123")) {
				//System.out.println("Successfull...");
		      return true;
				}
			return false;
			};
			
			
			System.out.println(checker.Check("admin", "admin123"));
			
		}
		
		
	
}
