package com.cg.training.lab8Exercises.client;

import java.time.LocalTime;

public class Lab8Ex2TimerThread implements Runnable{

	@Override
	public void run() {
		try {
			while(true) {
				Thread.sleep(10000);
				System.out.println(LocalTime.now());
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public static void main(String[] args) {
		Lab8Ex2TimerThread thread = new Lab8Ex2TimerThread();
		Thread t = new Thread(thread);
		t.start();
	}

}
